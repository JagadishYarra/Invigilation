<!DOCTYPE html>
<?php
session_start();
?>
<html>
<title>Profile</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<head>
    <style>
        #content {
        position: relative;
    }
    #content img {
        position: absolute;
        top: 0px;
        right: 0px;
    }
</style>
</head>
        
<body>


<div class="w3-sidebar w3-teal w3-bar-block" style="width:20%">
  <a href="display1.php"class="w3-bar-item" style="font-size:24px;font-weight:bold;font-family:Helvetica,Arial,sans-serif;text-decoration: none;"><i class="fas fa-home"></i> The Invigilator</a>
  <a href="schedule.php" class="w3-bar-item w3-button">Schedule</a>
  <a href="index.php" class="w3-bar-item w3-button">Edit</a>
  <a href="3.html" class="w3-bar-item w3-button">Avaliability</a>
  <a href="changepassword.php" class="w3-bar-item w3-button">Change Password</a>
  <a href="login.html" class="w3-bar-item w3-button">Logout</a>
</div>


<div style="margin-left:25%">

    <div class="w3-container ">
    <div id="content">
    
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAflBMVEX///+kEj+jDTyiAzqgADH58POhADf+/P3s1tviusWhADWeAC2gADP36u6fAC/qzdWeACnarrmyOVyrIk3z4ufSl6adACXZqbXVnautL1O4TWuxR2HPkKC4Vm/KhpfBaoHCcYXGe468YHibAB2mIEaZABO0QWOYAAq5YnWYAAAZjk8TAAAgAElEQVR4nO19B5ujLNewiIpgAQ222Esyu///D36g2BKTmcxmy/1877n22plJLBzg9IKm/R/8H7wEyP7bI/jNgDof/+0x/FYIANGdmv/tYfwuMJOTowMALFb/T25VuwW+xA+MOJ4D828P6L3Ak9wgM34SoD80FP3tYb0LeBpCA4Ib0C1jaPB/H0lEK8Du0ZuRdOIy8f72GH8BTNwAttuc9wANdo34f3IpTVwDx3qOnkLSdcLqP8ddaQP8L6GnkCRumPyHuCtKslfQm7er+18RkyiF/qvoTWDF5X8BR5wd4qdDQlzD8B3H8Q2DEAseXWU5zb/OWlHj34oGIfgcBsOuLaIkwBKCJKqa8uQwn9zJERf825q5Gbp77IgTgzrFHrqXBwhxHJ19ZuxJVnfSvzDwrwI6bdZEF4pMWOHPOCQP6sF1t2vJkj8y2G9BTZZhQh90wVfNJLvIXXddSf+f5Te2MS+f63TBayyDFyGz5tnpftMAfxmqiQihA4oj9JDHbSrB5t6BmoZoPat48b+qxf2wRvxCwQ1xSndfeVVN0Sk24jj2WRy7Dsm6CN/uRrOAhsSRyZvNfwdNM+iAQ86B1lhCM8lH1HDYNeMI1TCvOW0DrzAw50ZrY7eNmjxzY5ZVeLeeKB2EOGXU7vw4ht0/YV15FRwVbMjKTtju69LZNeJJeZrWSXBUmmu0F38JVsnlIpme+SNrwrgXavcGEYGjQVrHmhSAIf3rOCZgYYLQGbBmNp3ioF4x+HGZqr94B1qv6KlGWerRmGqFC/OhlTZICy5Du9nUZmHMLAvoRvZ3NQCeryoaZIWc7wqPo8Ul641mvs5EZohDo/exlhGfuYwiUONICHfeprbGI3jJ0lVy8pKtj/XrP4/XAoGzSGrdKSX/RGdYBg1O3D4MtC7HVjeOm8pRAk/rBUpuYic9RwBp5oVqwBl6ocMJwmN9s8pPDFbRSsBfk49tvIzCgkoRoViuAGxs3raVEVdROH4chFHJTM1vxO5FGv3Jtc7TcO9pl0DzzlYOaTRE2WW1n8xmszvc4G+gp5nlQi3AP3NkT6NDkQGBWLJswJjkYp2mj+0fuSAoOuqcNi1NjUZaBE3tJNbtyoXGDhoNFazvFhwxnDUAsUGqP4+fxrNlH+msEAv60ZSJ5DyXAqW9h1ikFXEmlutui+H+KtcEa56YiEIQbZJ6vBDMRztn+OS0Mz16ub9MofPn1RwbwnUTjYxQkCFtw76WgsFptBRe++KDonvVO6kWMSnuasR/554ZmcaTHmsIMH/RvCtn2anu9Q+LDRqv7w5nBoGq3hBb0e76jHExYFsLbgnIDAKEuqi8WRKbumLT9tDTkp62bHkiXg1Ikv1R2xivbMDo5smlmZtajcZ/AopWQbEDD/TxVQj14k5fczzNjsO4HcTOjVg824g2WFC0hj8Y0UmMBUHWzB9WMQu05IK1QoiFqD/k8DVrz4wefSMvTxAexOKboCsupVoxbyV3CP+Y1IichQOwmcmZ50t0BoKkhJyTi3pg1AuIB5Qa+uOBmlBoOQ3zNKqIW7oNNigeTs77oVrF4OJxoBaxNdtpNS6YzEPgfalFxMofXhDEArmPRMwR6i7F9Bk6L54R/c+EV1u2isEZwSQeXK61vRB+6c/HE233tVYRwB4uIko1REqxguIZXV+rffBnUUTNKufZjGDRt2Y2IIQjT0P8Mc+jfaM1BJDiyQtoz8Xz4oQanZtPj0LnVfQ6v9uJgzaKzEKDbd/JHfi5UJYY1tYnXgqBAhbqkBVqdqkWEYWLegOcZ9Pz6+CdVoV4EQh1XwouquGP6LPbJYadBfTsc+ldErF+3Uzn5rA64/z6N8p+vPH6kXkhOqFv1UIb0aqPz4iECjrsINDBp2NshSUpFEMaq8Ab37jI3ey3CcZi46+HoRpl7ZeNhzImlZnP3izXsPwEw8nejyONmzzS/FahQ1f+BiD5PfzGO68kCHSosGkvlF8CBEE/stDni5P0ybhLw8eXoIk/CxRI4TUlo+FpUmyTDYq63/6GnZqsxoyAXs1i9DPwKl+qMJVkcm3z9BlX39ZaAqwnVnvRz2Nve9L3gXYWBsoI9TZgQIY3L6NZQWMbXTDa6fPkI6U/iy6DSsOml2daB3XE4mEDkMfWnrdKg8qj4mGhlagVR+HW9a8z8CljewUQ20VPoNJK6KX1+h337h7rK1KGi4k3XUDah5e0g1pCqknEUCiUt3lRbbIdA3AfP+U7EG4xXIiQFloa7xQU3j92OFDnJH90Fjw/uoTPu19rpeJgXh2qRfWsQqTOFkPjva6N63aH+Jv4l93nOxQL6xEPQNnEjGgMnEdqT7PwINxq9NxIC6X8ubDo3T413kuJ2zXcL4GZltfNuxB4tHmauJl+uULygNXwVaIiYJtFKNTchq7+Yu5vMXyr/oZOGwz9p2IPfxwvEO5nTQYzEO/n31TboNzMHY0xFiTe7R4XbQSW+1b1DW0mz/jE75WX0y17A8I2ZoNPsA/9ZotFkwqw58TBIIU9t3dhjc0+fSZzXge+ittPVS77g04/tkttZvG6qVID6Du1BEzLoeZmBmlE39IaXhcRPmPbLwPeWPW3LOwuRlZP2zFsNp+V8WbGOdmbQdJgkj8+7rZ/e7fly9WJ+gX9/euQLFMH7zSu0rgZmDnZjfhjHUEbb7nTtNfiRWJ309rtpmSE4l6BsJe51sE7nW/VImzvjWxUwptXJWwMYaxKB46Hnde0G6lpNqDNSQji/nYJpVvrDuplEd13OqYWcXi0+VG+H7+QfI38EcHZgHXd/VpMGAJj+jTxR9fV6ZaD4f5IHqws4a0ejedPRdlKEiOueAxWoIsi2TbeDx4p6QrziWBHCZooNYAuzq3LsThYFvGJ8vcy2DOGenb4vQlmazGAI4rlSK3tRLPcvWG/C1WPrlP7Mu7OeMIHAWVZ2/0DBJbBwPL4gu9AMItD/4Ee4QEVVkDDOMBJPeUTo6ji7V28yvp5FUaRNs3DrO01RBn1xkNnjtrjgtW8L1+zmYdkPLqCAzWh9uSQr8Zl6+QoUbZLHgm6NJlNPV1QqjlaXqbSdbHinh54vEB4nu9j7/m3IFM62xPDjjtK4CUTDY4eQyo3IGf3pkSgeD7j4le5EhUZP/d8tVez8LGwQ/Nw3LdZiHzmpPETjdT+aKZfutHEC0beL5lI0B+k4ileI4yjs7zNU3pErhALn27AQm0B68fruBzDvC0e23USZtaAJsthVMHwxdSiI5NR7Xsfex9yyZuJgxVsmsLSekph3Fo3+XugVfL+E3uFKnPfHuXYqEZLqR/1BxImm9ewkHxGGb5UiZfG+cRpl6tN9Tg88CLMD7zVXW4BXybCiMbd3AD5KxkdbLcwc3zmjVt48n0oPix472ccZBY37zIRPaDfy59yNwoVSws+pleWctN5UiszPyjt7xmC0pF0oFFPSsTxYc206YplzXdblZ7XP00V/bKaX8NshnnCtzOGukuzIYI2VE7Nj3GfmVC+OpXqKRJUfKOsI5rPai4cs8TCceqUoFCPkJrPZkZRe+k2CIfLDL0FUrUnrB110GGjwfFQxWeji6Io+QMWMrGd3bJgAAZr9k1ClmGNyu+9SanBH4rzcnDaJBDBffr3PKT4PTJf8b1buwlVl24ZA+omN5NWTD8rySw8jeYM3lvjyORJNksgnYXjHeFIi7RXIpf65zVfo+5vfNzztnLeIvNnz8G9omuHGy2uUjTYTiiGQrKhRtV0GfcS0cvWlCenMQU/4uPIZ1fzRisN/OwWEaRYw3tYjamkz5FZEV2WxBBBQNOg6pGH80Kja26a0dxJrmrj3yWAahIJb04Maj+WOfHOPw9sjHlfvcVXMxtk7pGQ8s4fxZJt4k/qdzeJsyLe+OeIf5MoyrOdjzmWs2Nak0qBylVeRJf86L2KEJ/FeL4OSqN5xLcSsuwhnk0pL53gSajeOaiF6LNauvCFNL9Y+6+dEmnhZGZ6GZiRsrMH+1ARoj68Q6tJJy3QemTNePVl5gPoPBrzqLPR1dhjAJs6vsCyKaKiQKhJ7PymXIaE5jQD1MrVTEhe9kDJMGcZ/Y5gaUEecYsZqLXw8mZSYFC2j6KICWo1MyjKDIBwnA97uK17ItmIWLAIWgyeRELVBJF36G3Ka+A88Yps5HF6afeZBTO49YYhosK4RVCmdQnUig/FV8z6cs+eVphV93eIi3KaLfZ0P9BwtiCwULrK2xUcEWBOJjZpFBVNCIyDC4AVjnePELDT08FHE+28RSCeJwyd51ehqFdMj2vt4fgBSWlStG2RUE79wyvcWlPPKPuFRR9HzunEyN7ib5sw1E9H35n5KgT4WTmTthH3PbS23MumXdwRoQLly0jjNWSHkkPPr6pAessaTo6fY8cWKnprneykz+xdjONuFQ3ouoa+reK6AcOWqtJlEREogn11pHzy6RFvocNJ+XjonEzBpZ0n2ex+4n0Y8wZ06aU4P7kAZhr+WS550NUFRsfsxpy2wVt46WRuzl4fc6kRmQEF2WWpI8AoPSaxBYP2gM9uF7FAM2nxph+SG/x4Mu/f0dPzHofipD7M4tBsh0t+k+KLcN53arvM5vIjIM4Rn90AUxvCri/hTdkTj/IezJM5CsTnnqOvwmRbrNoTsgtwGao9AdDzZSp5at1nw9edsjg/plMJk6klnpffvKHKLmBTITXudec92QpYDmnPlnl66t1mNwSZvx5o3p2ggMQ3DENlpFtjwdB0DXQN+cXdkgtmg7N+X7dOW7c/RbuPJAOEb7LxtcY/UGl4cmZ9va014E22uOXW8YaVLKqsQpkTJ6Y8KPEYjdeNsJBftHf6HWm007YNEcINY2Fyq3DILM638JkRWkc/Ejxe0LnxthwWoXkJIXFdAvWRfJEnSwwDAIVMpcxiHA26JbO2pi8Er9at8fL5Xs/cvoIdV9zWFgnfGEDk1wcxAhM3PsuXCU4UI/VLoZ5VHWRAs6W2nQlGxDOWSBWQ1FrBrqaGy0F+4aGBgVpeflY3G7NvTjBOxpoH1eD1ZxkTL4EdPlEeEG1Zn01EomThEhClIaKxLsBircYhknxZhx4nSKsdscS67th8cUxiVUc8uvZ5mvXxkz5ENYHnt+WZYgafmhaS0Q29VZkqo0c/IfOaZWdZ07SoOAJFc5oBoxC/dWrBdD7efj1lJTIVSTLbrKBgnE/1lRoCy3jTNh3zcz9Vce3oas6+aD/RQkuHrnQVLrEwsQsmjVWmxeFZZIjlxicmSJZ0S8TFjcwh+mzwnVAc4PAeDEcRd5And98ZSBla0h8w6XqQrUFpp/BUKrN11ppZbJLWnMo03WLR9+D19sHowbvek7mPxnHd+0s8H+RtQDd8wJxNBrEPVbpFsujhVmjmS6C1XftLQK8aV95q1pYMbIOPSXGbg/sijkmneYsnasqwvo9GIjuorkYcwzLCE8nPPRWEtmiON5FSmz2/1gltzEaWmHPJlqWu0Qfk3QR3OU5LGMfOtQrsuzWcIpD6O3JqJmv6UfjXo0kdwr7P2gQFMxniaW/qgzljZWUo3WprDHtzgQFLJ0VIcP9kjZCkbdj3MKwTeswwVSDYeJ/19NDVJsHktOjC2ckrlJIpS8ygsy0vBEC6V0eNDYr2FPQWtp7K6bJalHUV5k8MB6Xhv8UCnnw+n/tekWIqOjQnX5/VIUWYYtveGv66j7niNsImHIlKqDxcqazXT5L+lziw/w7VWzFD+PmVk4dPsIypBQjjxbxtKb7xD49f42VTTl4XPx1lwJeiZspP85bAhcJwDGQlaRJg2ZzERBL2F6pUJx9PNCKGqaQD7NBBVyjxvXJ6wnDiwmIRlbfeuhnD+DbTsynFQZJKs1+J3resoTIXRv5WhtkALD/uPz56IcaysPzRtFUVpQnGXBG/Q83Js3NGKlTr0PTI++ZjxZr0wZtwJbN+YCGOsUClqNrmR3nNhGCVr4wdCwyZDGvNo3oLHSpNQ4l8OZUeFyCmM0nlCMQQ8uwEWKVSpQWGIxmuGDKvO3LNWA139hhCTeFMUMPgKcvFBIoZLOQEio3DueeZaueoJ77FE6Xm/2me3LSLJgzFVISKcShWwszbIMW0OTtlL+uZOS6/YDAqhEBMZN5Rwe6FKnT1Fgtxjj0dJ+1tYBqmrC6cOEyMFnd5c+R9Iq1SeKzaG+fCSWa972FJwwyLcvAOiT/rXeSzty5Jld60TY1AFZwZODlywAnynBaZ2aNWAU9L9PqW09zBPO1vUb1NtcOeqg+SOpd4UCN4uT7qYc04EFiiAw8cPKHpBlaNMyKL0cslx0JS3JP3KeXinb62wzw5k9uC31SNYDWAnRYzQggp6orfhTXfjAVTLqXOLYqQ2aOQhHE1+s1kpHsugxcEeWJAMJq6SiWLuddt5tyC99j5c8z8JgEaw1FsCOWxqwSzo7KW2xmB9YnGz8JsdjsNAyYsxcGzrV08DToD566uE5ZRlBNgxZ2pFZfpfieuNS5ZddUJlffjIoQE3MfyTbWb35QIrQpVbnPjvYDS/ex6dAbpyqUlMXyINdoMFmNYSzPXsKAEYrhZogUXBw6trQWuuEw6lM3ldrp7k9B6abDnmXNK7/OQ35dhLgBQE8ZlDFBCKiDaQrpCFGHpSeqyHkRcDDGthSJiJ01X5mXXivGaVSPMBpMXMM6kLw0l2/uj++eqXyfinOmBvQXBxVEvOIgEkxnuF8AJIy6Nc5oUEV7Nu42UQxRHMpiI5KxlzlceypSF86V00BdA8cg58aE24FeAMD+UkTehx1IkrFms2W2eDcOQ5S3XJN0iuZ9lgWrmMOtLz2TTNprLnsm7koRnR7Yyven1/CXomtTWUMnYR4Gufk8D6XCSAN2YBr1TovbCWI00GjXd1x6pWhDMCsR7kr60NUf49WRHM4GWlVEzJDrc1p3BK3KBmyM6QHIXQfsUFunqvCtHeMnz/lSZ2oFZhHFsWbmJZccla6ucwtI0ZPIFNgG0YnZ9rbPekpV955P7Nsw+NGWNoeArMDLT9nxK6GXU4WiypIHpYstKEQQ/7CgrWxmWwF94YqI25ey0fJO8lzAz51n7bmPjc/DD+fyDFMZCimfCah1do5DBQINMfASUhc7TzPnCEz+UC272tT73w78EwY2bz/sS47NYD7ooSbHUBfAYgcAhEeQ3ZoaJT8QEBGkSdbB3vsJKiVKqlgie+77yvKXUaPa4FWH+NQgFZHm0xo9qttiZHi6umbzgq8+aptecPSL6k6qTl2FxlJFvqUkbMW+ejz59BRaPyFsLgZf6Q6XX/AL86ryvTq33FQVp24TeOZ0dvwXu0DWpYKrH1yrde81meZu8l7DWAc+LmFz8X4W4RoimhdDGz2VZt0UaUA8JFpR0Q98zZ38xM1TPqNUv+Zbc0hno6tCdm22XRP9FgFoCmUEmNmrJtvsOg1eh6iHZ+9qBu4vnOFqx9v0a3ld+KOtfFgwtleDGT78MgrGCG9ChZTiDPJqFlrtrFYPyNkv4lsjaDGiTBzTnLKBfBg01MfONu2RaHRpWSfcvUANpNl3f31gkuylqBF9oqvASUIyD7N5NBWB8PnjNtlvUr7P1HWzzCd1ZHbS/DYLSkqpt2iqhpukd+ouB0Wl8vl4pLyjbXPm0r93rsHPLE7VP8U/2LYhDrZIsxrKIwXzoHiIoMQTq+rkssNqGP56k1n8Hyu0olk5m1X3MbNrIRLDFWIWRxBD9/RkWRsr74xs3j2DhrA7rc3DC3jGmtwr8HR2CTQOXzrAOgGRtsHGXIY6T+kTW71nhfYIhNITZgWN1eTIPYrfYj9r4fA/Mk7uLPCw5YEccUhuzGNKqLs/X87mTqevezcVaeuchXlcPGiQP0OZy9a5mm9ipG6B5J4bS+7kdkw4fS1tEq5www1WiHFpSkoPyJusWn5wD8tMtl4HuLg9xhGAb+7Bg9P7joYLtsTfWYiLwGyaJQ3Z/Po6YEtfPsVjbGUwtKP1Ro5n0G8F0fMaySaPZPnFGZNs5Efjlb2md6IUbVjb3pNNo7C4E5ndawx7mqUNhGp4V4RLYijHSpOiuWXbKwnNdJGNWDsfNsCFpNjO17RE2ev/bOny2m526nHdD4aJBMorjI9xm6G3szNcSBtttIhCycdJmjDlko5C6+XzB2qRV7NDf2E442FRKLF4Selqw9qKDgD1cZAXDdPO9VEEZAVkWZidgMMdwrZv1h+XCZdb75s60vwno2l9bX3r8mJ4Cjux7XTrnQQeYKz3WoUwLfgVmBIsVwd/aoFUCz9ZWVEcGWnJHhzCX/vuou3Yvu35n2NRwsIN0Ahkd+NaRn3YSRcmdGb7tr73Ueoq1MSfQ7NC5yb+XHMaeEnDMF2Ddi5t8KnbPY+wydgwhnV5XcdrecMvzsCkiU8iszadXFFH7EUvoQ1uz2ww6gqYUx4DQYF7VS/3yBejZ4gxNFu6lH3QAqvrWHiMZ/av8x46nns00vG3Zj7q1t9l6fAjWx+0LHXnAj0ej5kcuOMhJSIIfFUfPiqGOwC+Xl246Xh5kQLVTq4Pael0Tx/6crdfeGoSoXugCkmXmvLIfLYH+4uctlgbPuCmF0sUD0L9ofaybsVppML73cQdTFFhGVl5OcZNpBKq74e1ZDbL1/bJxNiek8BVkAtMsq73xr5dg3TX1emzQQUEEUpWrMmvz5X6mY+HARGfm/RavnhL/28AMNwRxQGfpFEhp5Tq/7FwcnU9w6lnS3rtEorXztdNtdvHCVL8LW6K3T4tosoaj/K5hXLdpul/GcEqFIiOKvL9XIzbqDcnWt6MIwO973wC8bsaZrDoOCQ9LZS9ybhXJvLxLlYvUGnuowIM4Ft2cNAM3VG5WzPimA5Wdgo2iWm+2SXko0INs02b85RZ8syN/bIDeNgdXeNnqnXXKbVVCAf0vhAPvAo67A8g2fUN09iAUWhfbM5Pc19Sa1UOqsxoFh91Qt7Ns7brKIvod2D6gXftrW/qjSGhedJs23C+23d3oumIymwfdULeN2tkbrVJ82myP8yNbgmc7W/u15mZLAGSq27DAAzLengFnkeruFV9559019uahxHokyO1GV2ni87Uvyfy5OASG892PkkIwYNNsQOPqg9t32OnZFdbhcAyCyGF9Wz5pNq5bThaK7sYPTkAWdONKBV/8s6q5EOClzsJzFn1O5+2iG6w+NlFwCQzHITkviC5wvLuGBnUIoM98w3XJCNI35cLhXOG7je1VMRG6FL1C14VZcehuMnEZj/2ZoJ7J/825F/cL8TaVyqZDT1a9kExtQwbbw4pOmVXIpxQC3TkdHZKOOJVNMZq66+q6aaOA2keLw1tXclAp2jg9PC7DtKPSH8+N1gnpCBXvZMEc+H5B6NuTuutjmxrAKZY0bZ04oIvsB4686UW6P1Tfi/bTzt1UPtyDsFi6E3Nn6quoPXS8t1ruzWnMXxf6kzPCbeyGOiwduxzqc19UaBhDGdEDLOdEFzG755fPSOVR5i8dHw9GJGv0fHeuUQF67lG71y0eePhqqyV4oaHpeNCCfkJDi3ts22Ppu1BydMWdpffTPTXB7QPXQzagb9UvIOklob9qgTfHVnu4Ci3DJ5vgaCfGA12eQ7fiYsabqS7wpf7X0mIlXsOqgCY1NkblLdbDJHRXTcMyGAsrvHkqAlunseOUyX3t5x0gWmTM2Ebvtno+SrP47gh2N+HiTUYaGPogG78RLx+PEX7FkUGlRGoMoeu1F9xYVsZrz9KHQvaW2b4LEn/rf+Zg1z8AGuxUR/QhmibHVQnZvpmLsdNBdz3RBIxMT/Ba+wT10JMlcCkBsJR0tB5y9yXAAkUoO3T5gIck482FA12/eHUS6mBfH+JuMnW9803ATUYiYFY2kcy5H2t6ZF0Rt2lQ1PngOrfLo8f77lDb4LMsWSilR9bAdcsH6NDWgrknS5716SDNl4COCpkOxSMcgFDE7FCHZx6LCWfpLpy4z7ZO2X3zEh1arj/utUnQCxrypf/3Lv6kG7dWjLh0SfIShAY7TQg/H//4GZnAqAVHhJlSu15P4zNV+6Rrm6EOph66QgfLuiQn3YaEhVrS7+9ryMMeQspMevStAW4dexrskqXlkgeh1XiUCbmX2HZqhkzywLGuz/1WnqIwACfJmpWu7va0g5ZUV1lkJ+2yT2FZdbcZ87wF/ou+NSA5U3YQMTutTYuYyYFRJLQhzMayn0QAFUm4IIm+cxZEHvF8VIFHUejT1m/k/FXcKaJFLMRSM7271Uxy9rgZ1AFAwz8+Zryp6Lzr5cqRNBX8hdnS826pQRBfKK/mN5p7U1k1ik+zmg/rmgnJ6rRaAppgsa1k3XZzdDsvTl9FUrDcMH0gypJh4TVGUFU0qWKc9Hw9FcaKp65DxeuLmE+8KRCW/GQ7QFgMpPWuKTc3WWBuOjy0b4qTYRzUx25BSFXjvvnMCnRjnQn1o9BqMlBl1I03z8aH+XKxJTVmokgI8Kf4mLBX0pC4cU03IXWXPdEkeHKebz5CjzjDYfOZBfBGMOlXziQb1yelWYjioabN4p2JXs0CCxcFoWrMoAMq3iL/h6G9Sz65N3y34OFmYPfNkiT/C9sj9XaFrS9DgK8Zs0ZhGepmuhj2ry4ideZ3o7GxpYnb06pbRbuxfnqGvUlbeJOYANmpum8FsQec7dtqWc0k+giD9awPmmtA+MCr+wy6ZfW5P7cTFVsunpbyRqjr/vmz+UM4jJeF1EncfRrwo6F/u/CWXHkmzKbNvd2y1+z+lfQMtJ5YnO4UYdoOB/25ZKLdp3uEt5N+IgX7p2OhVxVq3R5KqBM3i264UrKSH3hF6tPJRJPZOt2txi6Q3Ar02WRj4ZFxvwOzEuN1Py8D8tJsxs+oq01EtrmfRjvWvKYecWte8QlPC5dmQ6BZByEfvCqmpMxniemDJ32dJuB5/6zvqgQT18thi/Cc5nNDXVnUfnC5Z3BQF2PwO33liPlK3lFCHPT2YZ3mkvhtdNqPUbcbx2AJBi7acbYAAAl1SURBVP6gN5cC9NzjJ7MaZlOfGMCNgh4v5QeHp+Wh7BzK3OFGDOoVVtNUYnueZHeG01E69SLxncazG+kCmA/XE0i61+hbeQMmrjJDZabosqErthiOjGxxvx/n7uZj4NRjycsYRmPuGmdH7u6535FfeAZtLEAaqanOrhzoSuM/4F+uGEEmldlCa4qDLtMhIPZCYX07azX/4RlW4cQyaM+DVzBsW666hp+PivoVGfqJVn6IQejQE5qqDmqoG2qLQWIwGDZVIuzeJ0fGeFxomj9Cl60ZqPLRLpVBT7FBUCgY2dzmBh7mC1Zq37f5S3RY1GcV7+FHhDM1DIKYtja1W2JEnDq6GBYZcAU3tqNMAiYgy7u6Lca+L3Otd5AWbS3L+A2Zvbdrzy7NUtf2ZBYUOcmeIX4w9ZIkR1HgFUwwvGLlY+d5vnot1Ck9TCyXlF7rArOjBsNa6XY8MYU9B+EmK1gmnFiEGIY/V4mInwYhYz4K2IL0KGcyWx3yzJQRfLcVf+lDKw1dVn4ijJ6d6n4P3mfO1QASoV8A6forelpktA+wHTq46GsaV/SKm3CyvsGXYPLBFL6sjssh0FEP0IiirDyVeSwW/Dzs8ppe+qnS4dWT2CdFUZrsRBMK7cHgYd/gHrdDy00udpg1OpOP0dTHFqZTFg6GY7uXjripLTb8ySwxR7UrLKZR2urOo/bzvxVoOGn+Q9oQy6Qst91MsykPiZdDxnMwAEv6WvWr6q8DZnY7YjWEpE5x0AhNDoYjZUPkhQzXPCdXjTYwN+UUyVf4n6n2vwtQAqRyLD3hbgBIbfdFgAtAci5oh2die+ncZAB2sigSllTmIBWu+LuQ6JztCw06waossVIBLy3AUMdjLhRrJvaBpVvhFBFy3dcKod+Oo+qZo5Mo6WnTUd9qqANz2T9IkCUtIWmRQE586gMjEZwf5jIXTw+9Pikcwmjh+rTOENQZilOMYuCF0agzTV4097n5+fshCZWWpWehY0LoZQ6uCKnk+du1HYuxummCA98tEkOsLI6IHtoUuxCgvpXxgs42oJ3pmPrMyxjmTFyZK+cM9IfPzZDfD7SbmqwLhiIkflIZvIQ+rYjsQ1eePWYEKbOLPokEG0kyj+gZdzCFrtbXtgFgbhuhRgX9Fj0XslCYEpYKwhAn/HZK6puBF9ni6YYDKARpCiwZxgmlSDCPyhjMs1hZscY/aUMAH5zEZpqf2xAYQuS1NNNZZuaB0JWWnpg++dRS+aNAW3dxxkjB3Q5WZ/pCyNNq9CXnpt2ySjM9xHvoDbofcQRO3IpL88yobJEKw2xJj4BGfA7+JfQmoFVGFlVG0OZpzCOo6cW76sCotc5Hgi/1vGOyyIg1WmaYlAvZANtB7fJx8YgPyuAfoL5DsJMuW8u4JjsotFr50yjyViZNCJ7ac2lr+fWVtM1ozC83QCK48CcOuL8OJk+b0HfcRS+dg3EQTJFHYUqelIAB1qq9jsZIeZCd8U+CsPeiRlaHGOSwJeTOlpCFUSy2zsLQ+vco7xPgWPY2sYhr+Ias9FqbX1hj6bYvg4gg7KLgH9+Xn8HYlDOt2rory/Kc5+L/rm4qgRd9HAD/H4SoeGOX/H8SmvjFTIP/HHgMXN5aYf8vgnd3vPr/HHhvPIf6HwV8+pO8lePfOqHRuT5QX6o/6K6ImBNfTa0cOzl9E7LZP2befHEyC+aehHl193TxwexzCk4vvevVlCi71+F5yJAdQ504O7B06DuOoevG+pn6i4xfTSB+d5x5tFG/XAp1y4nL0DprwOUhm65T4Isv+7mTADqx9R55ja+vQ/HVsKaPxOv9/kV5ih0j0by40rBh1ckWgjPMxI/Itdrp70D8VxBSiR+NBdL5uvH3+a1ovf0Ec3FHaFRa5hdeEtQWXB+ewXOw2PX28nEIr/ItYiiB+iQdpt/h+KMisEheJCqPyfkngvLj2xT4xs2nC8ZHIlsmQNtsZIOBsR4TlhjHR4aFY9sVHGdaNnZJSY1Ns8LcbY7uKd0xJBGvNYbmMP1ujKOjjvW6TZJcCtkOBqEthl7UNE1myRpygaHkChj6zCjNYwx3XlxeDmexpIUOxxN2k76bMIwmDFEqHt0M+64zad2MMIyN4tAeQxmbRsb4kcDwGzofHRpZS7TFkDJDUJtrhAuGNNZdEGYkcbcYjs0sbjD0mOXCS9Axd4BjBo6ZTo0PpzX0hJ0hSFjf99fEOSO+JMAthmNFsfcGDPkPg7DG2+xSFELStQIKbcawdS3prqUnfcUQnWc7cIth67qFh4nlRJqngkSZnEBNEDQaH5Q1bTvcdg5KoPi0zciKYTDaX6p7C3LdVDzjOxjatUtYy1vQWAuG3DDWrIUJwyKevgw2a4h6XXeYdL5tMSxl20N0Guksl205kxDoQ57nmS4xrN2xDvCeDiOJ20SHE4Yt0YkwrnWJIQ51PZMNB/WXMUx6l8mTjO3MABsMN3mWE4ZcHfkOwWaXni0XU1kJscWwYLWsOyfeeKq4NtVFyvY8ZGyLGo1ThcI7DD1Zv51vMMSx1QiDc9yltAdAoMsM8PoaFjAQj2yYE+oTtzpfqWCD8qug5QuGWgQwDaTbe4Mhh3ImbukwzsRuCjvJJNhIThmBHcYyixzJYskjDAWb5vKAvC2GWnMJFk5TMKsRzyjc79ChTJtzSKQxiSHtmyb28Idcgd6VfZsUhkKW98yHjbXlNDy4x1BLRxzMseJsZLio7DfSIuzuMcS9kWYwvsFQk7l+CkPx+u9zGrsUC2grXtqGYgxYq85I1o3Ih3uxSjy22x8tV9IicR5LC62dMgOu/toWRV6spMWY1YJCY4dhrBMoDWOFYX8nLcR98hmUfQfDqo9l1jVyJIWkls3lWRIVaDtBc3KbZP1GS/ZOY703ddZkgqCHN1HNCUV0bXafJr0xSvxK2r9tv/uyICyTZ66U/Sjxr/2CITr1m1wtQRff2aVKDTKbSE4uExSfnj1anoep4ha1u6rR6VBqb1MOaYe3ekY63nGbhEJVrtNZLi2+6W+VjEYxUqky0YoVareqNip/3RCKBpgR4tia55L8C1Ycom8xvtDzBAwF9D1GFw+YTMSsjZx9oViz+LgcVpi/CumTplszJB+Xw3L9lwGFPdIKh3jdQX3+LZgN7t7RYdSrP38XanDzljN1ZAEr6MW2oV8MXKbvOoLxCxC8ycfzInUl/Z8LtOCXG9S8BZJXLe9fAHz5KyhG7+1Q+RSC/3l36/+38P8ATs3+yyufSpcAAAAASUVORK5CYII="  width="50" height="50"class="ribbon" id="right">
   
</div>
<?php
    #$email = $_SESSION['ma'];
    $email=$_SESSION['gm'];
    $_SESSION['mail']=$email;
    $con = new mysqli("localhost","root","","Invigilator");
    if($con->connect_error){
        die("Failed to connect : ".$con->connect_error);
    }else{
        $check_id="SELECT * FROM Login WHERE email = '$email'";
        $res=mysqli_query($con, $check_id);
        if(mysqli_num_rows($res) > 0){
            $fetch = mysqli_fetch_assoc($res);
            $fetch_id = $fetch['id'];
        }
        $check_name="SELECT * FROM personal_details Where id = '$fetch_id'";
        $res1=$res=mysqli_query($con, $check_name);
        if(mysqli_num_rows($res1) > 0){
            $fetch1 = mysqli_fetch_assoc($res);
            $fetch_name = $fetch1['name'];
        }
        $str1="Welcome back";
        $str2=$str1." ".$fetch_name;
        echo "<h1>" . $str2 . "
        </h1>";
    }
?>
    </div>
    <div> 
</div>





</div>
</div>
<div style="margin-left:850px;margin-top:100px;font-size: 20px;">
<?php
// Define the month and year
$month = date('m'); // Current month
$year = date('Y'); // Current year

// Get the number of days in the month
$days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);

// Print the calendar
echo "<h2>Calendar for $month/$year</h2>";
echo "<table>";
echo "<tr><th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th></tr>";

// Get the day of the week for the first day of the month
$first_day = date('w', strtotime("$year-$month-01"));

// Start the table row
echo "<tr>";

// Print blank cells for days before the first day of the month
for ($i = 0; $i < $first_day; $i++) {
    echo "<td></td>";
}

// Print the days of the month
for ($day = 1; $day <= $days_in_month; $day++) {
    echo "<td>$day</td>";

    // Start a new row if it's the last day of the week
    if (($day + $first_day) % 7 == 0) {
        echo "</tr><tr>";
    }
}

// Print blank cells for remaining days
$remaining_days = 7 - (($days_in_month + $first_day) % 7);
for ($i = 0; $i < $remaining_days; $i++) {
    echo "<td></td>";
}

// Close the table row and table
echo "</tr>";
echo "</table>";

?>

</div>
</body>
</html>
