<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "invigilator";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
else{
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form data
        $invigilator_id = $_POST["id"];
        $confirmation = $_POST["confirmation"];
        $reason = $_POST["reason"];
    
        // Prepare the SQL statement
        $sql = "INSERT INTO reason (invigilator_id, confirmation, reason) VALUES ('$invigilator_id','$confirmation', '$reason')";

        if ($conn->query($sql) === TRUE) {
            echo '<script>alert("Reason Added successfully")
            window.location.href = "rm.php";</script>';
        } else {
            echo '<script>alert("Fail to add reason")
            window.location.href = "rm.php";</script>';
        }  
    
    // Close the database connection
    $conn->close();
}
}
?>