<?php
// Establish a database connection
$conn = new mysqli("localhost", "root", "", "invigilator");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form data
    $invigilatorId = $_POST['invigilatorId'];
    $confirmation = $_POST['confirmation'];
    $reason = $_POST['reason'];

    // Store the confirmation and reason in the database
    $confirmation = $conn->real_escape_string($confirmation);
    $reason = $conn->real_escape_string($reason);

    // Insert the confirmation and reason into the 'reason' table
    $reasonSql = "INSERT INTO reason (invigilator_id, confirmation, reason) VALUES ('$invigilatorId', '$confirmation', '$reason')";
}

// Close the database connection
$conn->close();
?>
