<?php
// Establish a database connection
$conn = new mysqli("localhost", "root", "", "invigilator");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve the invigilators from the login table
$sql = "SELECT id, email FROM login";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $sentCount = 0; // Initialize a counter for sent emails

    // Loop through each invigilator/faculty
    while ($row = $result->fetch_assoc()) {
        $invigilatorId = $row['id'];
        $invigilatorEmail = $row['email'];

        // Retrieve the corresponding invigilation schedule for the invigilator
        $scheduleSql = "SELECT date, day, session FROM invigilation_schedule WHERE invigilator = '$invigilatorId'";
        $scheduleResult = $conn->query($scheduleSql);

        if ($scheduleResult->num_rows > 0) {
            // Build the email content
            $subject = "Invigilation Schedule";
            $message = "Dear Invigilator,\n\nYou have been scheduled for the following invigilation sessions:\n\n";
            while ($scheduleRow = $scheduleResult->fetch_assoc()) {
                $date = $scheduleRow['date'];
                $day = $scheduleRow['day'];
                $session = $scheduleRow['session'];
                $message .= "Date: $date, Day: $day, Session: $session\n";
            }
            $message .= "\nPlease confirm if you can attend this invigilation slot:\n";
            $message .= 'Please see the form link below:';
            $message .= 'https://forms.gle/WXbYA8rNjbonqAiW7';
            $message .= "\n\nPlease be present at the designated venue on time.\n\nThank you.";

            // Send the email
            $headers = "From: vdhar1180@gmail.com";
            if (mail($invigilatorEmail, $subject, $message, $headers)) {
                echo "Email sent successfully to invigilator with ID: $invigilatorId<br>";
                $sentCount++;
            } else {
                echo "Failed to send email to invigilator with ID: $invigilatorId<br>";
            }
        } else {
            echo "No invigilation schedule found for invigilator with ID: $invigilatorId<br>";
        }
    }

    // Display acknowledgment message
    echo '<script>alert("Emails sent to ' . $sentCount . ' invigilators.")
    window.location.href = "it1.php";</script>';
} else {
    echo '<script>alert("No invigilators found in the login table.<br>")
    window.location.href = "it1.php";</script>';
}

// Close the database connection
$conn->close();
?>
