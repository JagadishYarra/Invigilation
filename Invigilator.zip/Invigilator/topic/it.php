<?php

// Genetic Algorithm Parameters
$populationSize = 50;
$mutationRate = 0.1;
$maxGenerations = 100;

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "invigilator";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
function countIDs($conn) {
    $sql = "SELECT COUNT(DISTINCT id) AS total FROM timetable";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $totalIDs = $row['total'];
        return $totalIDs;
    } else {
        return 0;
    }
}

// Usage
$totalIDs = countIDs($conn);
// Fetch examination schedule and free slots from the database
$examinationSchedule = fetchExaminationSchedule($conn);
$freeSlots = fetchFreeSlots($conn);



// Close the database connection

// Run the genetic algorithm
$bestSchedule = geneticAlgorithm($populationSize, $mutationRate, $maxGenerations, $examinationSchedule, $freeSlots,$totalIDs);
// Run the genetic algorithm
if ($bestSchedule) {
    // Prepare the SQL statement outside the loop
    $sql = "INSERT INTO invigilation_schedule (date, day, session, invigilator) VALUES ";

    // Build the values to be inserted or updated
    $values = [];
    foreach ($bestSchedule as $row) {
        $date = $row['date'];
        $day = $row['day'];
        $session = $row['session'];
        $invigilator = $row['invigilator'];

        // Add the values to the array
        $values[] = "('$date', '$day', '$session', '$invigilator')";
    }

    // Combine the values and SQL statement
    $sql .= implode(',', $values);

    // Specify the ON DUPLICATE KEY UPDATE clause
    $sql .= " ON DUPLICATE KEY UPDATE date = VALUES(date), day = VALUES(day), session = VALUES(session)";

    // Execute the SQL statement
    if ($conn->query($sql) === TRUE) {
        echo "Schedule stored successfully in the database.";
    } else {
        echo "Error storing schedule in the database: " . $conn->error;
    }
} else {
    echo "No schedule generated.";
}


$conn->close();

$table = "<table class='custom-table'>";
$table .= "<tr><th>Date</th><th>Day</th><th>Session</th><th>Invigilator</th></tr>";

foreach ($bestSchedule as $row) {
    $table .= "<tr>";
    $table .= "<td>" . $row['date'] . "</td>";
    $table .= "<td>" . $row['day'] . "</td>";
    $table .= "<td>" . $row['session'] . "</td>";
    $table .= "<td>" . $row['invigilator'] . "</td>";
    $table .= "</tr>";
}

$table .= "</table>";

// Send the HTML table as the response
echo nl2br("\n", false);
echo $table;


// Perform the genetic algorithm
function geneticAlgorithm($populationSize, $mutationRate, $maxGenerations, $examinationSchedule, $freeSlots,$totalIDs)
{
    // Generate an initial population
    $population = generateInitialPopulation($populationSize, $examinationSchedule, $freeSlots,$totalIDs);
    // Iterate through generations
    for ($generation = 1; $generation <= $maxGenerations; $generation++) {
        // Select individuals for reproduction
        $selectedIndividuals = selection($population, 5); // Example tournament size of 5

        // Create the next generation
        $nextGeneration = array();

        // Perform crossover and mutation
        while (count($nextGeneration) < $populationSize) {
            // Select two parents randomly from the selected individuals
            $parent1 = $selectedIndividuals[array_rand($selectedIndividuals)];
            $parent2 = $selectedIndividuals[array_rand($selectedIndividuals)];

            // Perform crossover to produce offspring
            $offspring = crossover($parent1, $parent2);

            // Perform mutation on the offspring
            $mutatedOffspring = mutate($offspring, $mutationRate,$totalIDs);

            // Add the mutated offspring to the next generation
            $nextGeneration[] = $mutatedOffspring;
        }

        // Replace the current population with the next generation
        $population = $nextGeneration;
    }

    // Evaluate fitness for the final population
    $fitnessScores = array();
    foreach ($population as $index => $individual) {
        $fitnessScores[$index] = evaluateFitness($individual);
    }

    // Select the individual with the highest fitness score as the best schedule
    $bestIndividualIndex = array_search(max($fitnessScores), $fitnessScores);
    $bestSchedule = $population[$bestIndividualIndex];

    return $bestSchedule;
}
// Function to fetch examination schedule from the database
function fetchExaminationSchedule($conn)
{
    $sql = "SELECT * FROM examtt";
    $result = $conn->query($sql);
    $examinationSchedule = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $examinationSchedule[] = $row;
        }
    }

    return $examinationSchedule;
}

// Function to fetch free slots from the database
function fetchFreeSlots($conn)
{
    $sql = "SELECT * FROM timetable";
    $result = $conn->query($sql);
    $freeSlots = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $slots = array();
            for ($slot = 1; $slot <= 8; $slot++) {
                $slotKey = 'slot' . $slot;
                $slots[$slotKey] = intval($row[$slotKey]);
            }
            $freeSlots[] = array(
                'id' => $row['id'],
                'day' => $row['day'],
                'slots' => $slots
            );
        }
    }

    return $freeSlots;
}



// Function to remove assigned invigilator from available invigilators for subsequent slots
function removeAssignedInvigilator($freeSlots, $invigilatorId)
{
    foreach ($freeSlots as &$freeSlot) {
        // Set the assigned slot value to 0
        $slotIndex = $invigilatorId - 1; // Assuming the invigilator ID is the index in the array
        $freeSlot['slots'][$slotIndex] = 0;
    }

    return $freeSlots;
}

// Evaluate the fitness of an invigilation schedule
function evaluateFitness($schedule)
{
    // Initialize fitness value
    $fitness = 0;

    // Create a dictionary to track invigilator assignments
    $assignments = array();

    // Iterate through each exam slot in the schedule
    foreach ($schedule as $examSlot) {
        $invigilator = $examSlot['invigilator'];

        // Check for conflicts and update fitness value
        if (isset($assignments[$invigilator])) {
            $fitness -= 1; // Penalize conflicts
        } else {
            $assignments[$invigilator] = true;
        }

        // Update fitness value based on other criteria

        // Example 1: Invigilator workload
        $invigilatorWorkload = getInvigilatorWorkload($schedule, $invigilator);
        if ($invigilatorWorkload > 3) {
            $fitness -= 1; // Penalize excessive workload
        }
        // ... (Add other criteria and update the fitness value accordingly)
    }

    return $fitness;
}

// Function to calculate invigilator workload
function getInvigilatorWorkload($schedule, $invigilator)
{
    $workload = 0;
    foreach ($schedule as $examSlot) {
        if ($examSlot['invigilator'] == $invigilator) {
            $workload += 1;
        }
    }
    return $workload;
}

// Select individuals from the population for reproduction
function selection($population, $tournamentSize)
{
    $selectedIndividuals = array();

    // Perform tournament selection
    while (count($selectedIndividuals) < count($population)) {
        // Randomly select individuals for the tournament
        $tournament = array_rand($population, $tournamentSize);

        // Evaluate fitness for each individual in the tournament
        $fitnessScores = array();
        foreach ($tournament as $index) {
            $fitnessScores[$index] = evaluateFitness($population[$index]);
        }

        // Select the individual with the highest fitness score
        $bestIndividualIndex = array_search(max($fitnessScores), $fitnessScores);
        $selectedIndividuals[] = $population[$bestIndividualIndex];
    }

    return $selectedIndividuals;
}

// Perform crossover between two parents to produce offspring
function crossover($parent1, $parent2)
{
    // Randomly select a crossover point
    $crossoverPoint = mt_rand(1, count($parent1) - 1);

    // Create the offspring
    $offspring = array();

    // Copy genetic information from parent1 up to the crossover point
    for ($i = 0; $i < $crossoverPoint; $i++) {
        $offspring[] = $parent1[$i];
    }

    // Copy remaining genetic information from parent2
    for ($i = $crossoverPoint; $i < count($parent2); $i++) {
        $offspring[] = $parent2[$i];
    }

    return $offspring;
}

// Mutate an individual (invigilation schedule)
function mutate($individual, $mutationRate,$totalIDs)
{
    // Create a copy of the individual for mutation
    $mutatedIndividual = $individual;

    // Iterate through each gene in the individual
    for ($i = 0; $i < count($mutatedIndividual); $i++) {
        // Check if mutation should occur for this gene
        if (mt_rand() / mt_getrandmax() < $mutationRate) {
            // Implement your specific mutation operation for this gene
            // Here, we'll randomly select a new invigilator for the gene

            // Generate a random invigilator
            $newInvigilator = generateRandomInvigilator($totalIDs);

            // Update the gene with the new invigilator
            $mutatedIndividual[$i]['invigilator'] = $newInvigilator;
        }
    }

    return $mutatedIndividual;
}

// Generate an initial population of invigilation schedules
function generateInitialPopulation($populationSize, $examinationSchedule, $freeSlots)
{
    $population = array();

    for ($i = 0; $i < $populationSize; $i++) {
        // Generate a random invigilation schedule
        $schedule = array();
        // Iterate through each exam slot in the examination schedule
        foreach ($examinationSchedule as $examSlot) {
            // Check if the necessary array keys exist before accessing them
            if (isset($examSlot['Date']) && isset($examSlot['Day']) && isset($examSlot['Session'])) {
                $date = $examSlot['Date'];
                $day = $examSlot['Day'];
                $session = $examSlot['Session'];
                // Determine available invigilators for the current slot
                $availableInvigilators = array();
                foreach ($freeSlots as $freeSlot) {
                    if ($freeSlot['day'] == $day) {
                        // Check if the slot value for the current invigilator is 1
                        $invigilatorId = $freeSlot['id']; // Assuming the invigilator ID is stored as 'id'
                        for ($slotIndex = 1; $slotIndex <= 8; $slotIndex++) {
                            $slotKey = 'slot' . $slotIndex;
                            if (isset($freeSlot['slots'][$slotKey]) && $freeSlot['slots'][$slotKey] == 1) {
                                $availableInvigilators[] = $invigilatorId;
                                break; // No need to continue checking other slots if one is available
                            }
                        }
                    }
                }
                // Check if any available invigilators were found
                if (!empty($availableInvigilators)) {
                    // Randomly select an invigilator from the available invigilators
                    $selectedInvigilator = $availableInvigilators[array_rand($availableInvigilators)];

                    // Assign the selected invigilator to the current slot in the schedule
                    $schedule[] = array(
                        'date' => $date,
                        'day' => $day,
                        'session' => $session,
                        'invigilator' => $selectedInvigilator
                    );
                    // Remove the assigned invigilator from available invigilators for subsequent slots
                    //$freeSlots = removeAssignedInvigilator($freeSlots, $selectedInvigilator);
                }
            }
        }
        // Check if the schedule is empty or has fewer slots than the examination schedule
        if (!empty($schedule) && count($schedule) === count($examinationSchedule)) {
            $population[] = $schedule;
        }

    }
    return $population;
}
// Function to generate a random invigilator
function generateRandomInvigilator($totalIDs)
{
    // Generate a random invigilator ID
    $invigilatorId = mt_rand(1, $totalIDs); // Modify this range as per your invigilator IDs

    return $invigilatorId;
}
?>
<style>
    .custom-table {
        border-collapse: collapse;
        width: 70%;
    }

    .custom-table th, .custom-table td {
        border: 2px solid #333;
        padding: 8px;
        text-align: left;
    }

    .custom-table th {
        background-color: #f2f2f2;
    }
</style>