
<?php
// Establish a connection to your MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "invigilator";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the ID parameter is set
if (isset($_POST["id"])) {
    $userId = $_POST["id"];

    // Prepare and execute the DELETE statement
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();

    // Check if the deletion was successful
    if ($stmt->affected_rows > 0) {
        // Return a success message or perform additional actions if needed
        echo "User deleted successfully.";
    } else {
        // Return an error message or perform additional actions if needed
        echo "Failed to delete user.";
    }

    $stmt->close();
} else {
    // Return an error message if the ID parameter is not set
    echo "User ID is missing.";
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Delete User</title>
</head>
<body>
    <h1>Delete User</h1>
    <form action="delete_user.php" method="post">
        <label for="userId">User ID:</label>
        <input type="text" id="userId" name="id">
        <input type="submit" value="Delete">
    </form>
</body>
</html>