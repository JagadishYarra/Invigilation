<DOCTYPE html>
<html>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<style>
        .button-container {
        display: flex;
        justify-content: center;
    }
    .form-container {
        max-width: 400px;
        padding: 20px;
        background-color: #f2f2f2;
        border-radius: 4px;
        margin-left:520px;
    }

    .form-container label {
        display: block;
        margin-bottom: 10px;
        font-weight: bold;
    }

    .form-container input[type="text"] {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        margin-bottom: 20px;
    }

    .form-container button[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .form-container button[type="submit"]:hover {
        background-color: #45a049;
    }
    .result {
        padding-left: 555px;
    }
</style>
</html>
<body>
<div class="w3-sidebar w3-teal w3-bar-block" style="width:20%">
  <a href="../topic/index.php"class="w3-bar-item" style="font-size:24px;font-weight:bold;font-family:Helvetica,Arial,sans-serif;text-decoration: none;"><i class="fas fa-home"></i> The Invigilator</a>
  <a href="get_id.php" class="w3-bar-item w3-button">Manage Users</a>
  <a href="get_table.php" class="w3-bar-item w3-button">Schedule</a>
  <a href="examtt.php" class="w3-bar-item w3-button">Add Exam time table</a>
  <a href="it1.php" class="w3-bar-item w3-button">Invigilation Time Table</a>
  <a href="rm.php" class="w3-bar-item w3-button">Reason Management</a>
  <a href="../Responsive-Login-Form-master/index.html" class="w3-bar-item w3-button">Logout</a>
</div>
</body>
<br>
<br>
<div class="form-container">
    <form method="POST" action="">
        <label for="name">Enter Name:</label>
        <input type="text" name="name" id="name">
        <br>
        <button type="submit">Submit</button>
    </form>
</div>
<br>
<br>
<div class="form-container">
        <form method="POST" action="">
            <label for="email">Enter Email:</label>
            <input type="text" name="email" id="email">
            <br>
            <button type="submit">Submit</button>
        </form>
    </div>
<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'invigilator';

// Check if the Name is provided as input
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['name'])) {
        $name = $_POST['name'];

        // Create a new database connection
        $conn = new mysqli($host, $username, $password, $database);

        // Check if the connection was successful
        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        }

        // Prepare the SQL statement to retrieve the ID for the given name
        $select_query = "SELECT id FROM personal_details WHERE name = '$name'";
        $result = $conn->query($select_query);

        // Display the retrieved ID
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $id = $row['id'];
            echo '<div class="result">ID for ' . $name . ' is: ' . $id . '</div>';
        } else {
            echo '<div class="result">No ID found for ' . $name . '</div>';
        }

        // Close the database connection
        $conn->close();
    } 
}

if (isset($_POST['email'])) {
    $email = $_POST['email'];

    // Create a new database connection
    $conn = new mysqli($host, $username, $password, $database);

    // Check if the connection was successful
    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    // Prepare the SQL statement to retrieve the ID for the given email
    $select_query = "SELECT id FROM login WHERE email = '$email'";
    $result = $conn->query($select_query);

    // Display the retrieved ID
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $id = $row['id'];
        echo '<div class="result">ID for ' . $email . ' is: ' . $id . '</div>';
    } else {
        echo '<div class="result">No ID found for ' . $email . '</div>';
    }

    // Close the database connection
    $conn->close();
}
?>
