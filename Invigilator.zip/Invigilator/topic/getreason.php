<?php
// Connect to the database (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "invigilator";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve reasons and IDs
$sql = "SELECT invigilator_id, confirmation, reason FROM reason";
$result = $conn->query($sql);

// Fetch reasons and IDs data
$reasons = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $reasons[] = $row;
    }
}

// Close the database connection
$conn->close();

// Build the HTML table
$table = "<table class='custom-table'>";
$table .= "<tr><th>ID</th><th>Confirmation</th><th>Reason</th></tr>";
foreach ($reasons as $reason) {
    $table .= "<tr>";
    $table .= "<td>" . $reason['invigilator_id'] . "</td>";
    $table .= "<td>" . $reason['confirmation'] . "</td>";
    $table .= "<td>" . $reason['reason'] . "</td>";
    $table .= "</tr>";
}
$table .= "</table>";

// Send the HTML table as the response
echo $table;
?>
<style>
    .custom-table {
        border-collapse: collapse;
        width: 40%;
    }

    .custom-table th, .custom-table td {
        border: 2px solid #333;
        padding: 8px;
        text-align: left;
    }

    .custom-table th {
        background-color: #f2f2f2;
    }
</style>
