<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "invigilator";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
else{
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form data
        $date = $_POST["date"];
        $day = $_POST["day"];
        $session = $_POST["session"];
        $SubjectCode = $_POST["SubjectCode"];
        $SubjectName = $_POST["SubjectName"];
        $department = $_POST["department"];
        $sem=$_POST["sem"];
    
        // Prepare the SQL statement
        $sql = "INSERT INTO examtt (Date,Day,Session,SubjectCode,SubjectName,Department,Sem) VALUES ('$date','$day', '$session','$SubjectCode','$SubjectName','$department','$sem')";
    
        // Execute the SQL statement
        //$sql1 = "INSERT INTO personal_details (id, name,dob,phone) VALUES ('$id','$name', '$dob','$phone')";

        if ($conn->query($sql) === TRUE) {
            echo '<script>alert("New Subject Added successfully")
            window.location.href = "examtt.php";</script>';
        } else {
            echo '<script>alert("Fail to add subject")
            window.location.href = "examtt.php";</script>';
        }
        
    
    // Close the database connection
    $conn->close();
}
}
?>