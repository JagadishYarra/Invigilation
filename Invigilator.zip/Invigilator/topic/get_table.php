<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <body>
    <div class="w3-sidebar w3-teal w3-bar-block" style="width:20%">
  <a href="../topic/index.php"class="w3-bar-item" style="font-size:24px;font-weight:bold;font-family:Helvetica,Arial,sans-serif;text-decoration: none;"><i class="fas fa-home"></i> The Invigilator</a>
  <a href="get_id.php" class="w3-bar-item w3-button">Manage Users</a>
  <a href="get_table.php" class="w3-bar-item w3-button">Schedule</a>
  <a href="examtt.php" class="w3-bar-item w3-button">Add Exam time table</a>
  <a href="it1.php" class="w3-bar-item w3-button">Invigilation Time Table</a>
  <a href="rm.php" class="w3-bar-item w3-button">Reason Management</a>
  <a href="../Responsive-Login-Form-master/index.html" class="w3-bar-item w3-button">Logout</a>
</div>
    </body>
</html>
<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'invigilator';

// Check if the ID is provided as input
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        // Create a new database connection
        $conn = new mysqli($host, $username, $password, $database);

        // Check if the connection was successful
        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        }

        // Prepare the SQL statement to retrieve the timetable data for the given ID
        $select_query = "SELECT * FROM timetable WHERE id = $id ORDER BY FIELD(day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday')";
        $result = $conn->query($select_query);

        // Display the timetable table
        if ($result->num_rows > 0) {
            echo '<table>';
            echo '<tr><th>Day</th><th>Slot 1</th><th>Slot 2</th><th>Slot 3</th><th>Slot 4</th><th>Slot 5</th><th>Slot 6</th><th>Slot 7</th><th>Slot 8</th><th>Slot 9</th></tr>';

            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $row['day'] . '</td>';
                echo '<td>' . ($row['slot1'] == 1 ? 'Yes' : 'No') . '</td>';
                echo '<td>' . ($row['slot2'] == 1 ? 'Yes' : 'No') . '</td>';
                echo '<td>' . ($row['slot3'] == 1 ? 'Yes' : 'No') . '</td>';
                echo '<td>' . ($row['slot4'] == 1 ? 'Yes' : 'No') . '</td>';
                echo '<td>' . ($row['slot5'] == 1 ? 'Yes' : 'No') . '</td>';
                echo '<td>' . ($row['slot6'] == 1 ? 'Yes' : 'No') . '</td>';
                echo '<td>' . ($row['slot7'] == 1 ? 'Yes' : 'No') . '</td>';
                echo '<td>' . ($row['slot8'] == 1 ? 'Yes' : 'No') . '</td>';
                echo '<td>' . ($row['slot9'] == 1 ? 'Yes' : 'No') . '</td>';
                echo '</tr>';
            }

            echo '</table>';
        } else {
            echo '<div class="no-timetable">No timetable data available for the given ID.</div>';
        }

        // Close the database connection
        $conn->close();
    } else {
        echo 'Please provide an ID as input.';
    }
}
?>
<style>
    table {
        border-collapse: collapse;
        width: 80%;
        margin-left: 250px;
    }

    th, td {
        padding: 8px;
        text-align: center;
        border: 1px solid #ddd;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
    }

    input[type="submit"]:hover {
        background-color: #45a049;
    }

    .button-container {
        display: flex;
        justify-content: center;
    }
    .form-container {
        max-width: 400px;
        padding: 20px;
        background-color: #f2f2f2;
        border-radius: 4px;
        margin-left:520px;
    }

    .form-container label {
        display: block;
        margin-bottom: 10px;
        font-weight: bold;
    }

    .form-container input[type="text"] {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        margin-bottom: 20px;
    }

    .form-container button[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .form-container button[type="submit"]:hover {
        background-color: #45a049;
    }
    .no-timetable {
        padding-left: 555px;
    }
</style>
<br>
<div class="form-container">
    <form method="POST" action="">
        <label for="id">Enter ID:</label>
        <input type="text" name="id" id="id">
        <br>
        <button type="submit">Submit</button>
    </form>
</div>
