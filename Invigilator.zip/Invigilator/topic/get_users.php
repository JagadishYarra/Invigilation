<?php
// Connect to the database (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "invigilator";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve users
$sql = "SELECT * FROM personal_details";
$result = $conn->query($sql);

// Fetch users data
$users = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

// Close the database connection
$conn->close();

// Build the HTML table
$table = "<table class='full-border'>";
$table .= "<tr><th>ID</th><th>Name</th></tr>";
foreach ($users as $user) {
    $table .= "<tr>";
    $table .= "<td>" . $user['id'] . "</td>";
    $table .= "<td>" . $user['name'] . "</td>";
    $table .= "</tr>";
}
$table .= "</table>";

// Send the HTML table as the response
echo $table;
?>
<style>
    .custom-table {
        border-collapse: collapse;
        width: 40%;
    }

    .custom-table th, .custom-table td {
        border: 2px solid #333;
        padding: 8px;
        text-align: left;
    }

    .custom-table th {
        background-color: #f2f2f2;
    }
</style>
