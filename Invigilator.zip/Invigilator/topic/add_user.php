<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "invigilator";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
else{
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form data
        $id = $_POST["id"];
        $name = $_POST["name"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $dob = $_POST["confirm-password"];
        $phone = $_POST["Phone"];
    
        // Prepare the SQL statement
        $sql = "INSERT INTO login (id, email, password) VALUES ('$id','$email', '$password')";
    
        // Execute the SQL statement
        $sql1 = "INSERT INTO personal_details (id, name,dob,phone) VALUES ('$id','$name', '$dob','$phone')";

        if ($conn->query($sql) === TRUE and $conn->query($sql1) === TRUE) {
            echo '<script>alert("New user created successfully")
            window.location.href = "index.php";</script>';
        } else {
            echo '<script>alert("Fail to create new user")
            window.location.href = "index.php";</script>';
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Prepare the SQL statement
            $stmt = $conn->prepare("INSERT INTO timetable (id, day, slot1, slot2, slot3, slot4, slot5, slot6, slot7, slot8, slot9) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
            // Bind the form inputs to the SQL statement parameters
            $stmt->bind_param("isiiiiiiiii", $id, $day, $slot1, $slot2, $slot3, $slot4, $slot5, $slot6, $slot7, $slot8, $slot9);
        
            $weekdays = array("Monday", "Tuesday", "Wednesday", "Thursday", "Friday");
            foreach ($weekdays as $weekday) {
                // Get the slot values for the current weekday
                $day = $weekday;
                $slot1 = 0;
                $slot2 = 0;
                $slot3 = 0;
                $slot4 = 0;
                $slot5 = 0;
                $slot6 = 0;
                $slot7 = 0;
                $slot8 = 0;
                $slot9 = 0;
        
                // Save the data to the database
                $stmt->execute();
            }
        }
        
    
    // Close the database connection
    $conn->close();
}
}
?>