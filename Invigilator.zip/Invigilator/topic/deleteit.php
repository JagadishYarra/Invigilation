<?php
// Establish a connection to your MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "invigilator";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Execute the TRUNCATE TABLE statement
$truncateQuery = "TRUNCATE TABLE invigilation_schedule";
if ($conn->query($truncateQuery) === TRUE) {
    // Return a success message or perform additional actions if needed
    echo '<script>alert("Successfully Deleted Exam Time Table")
    window.location.href = "it1.php";</script>';
} else {
    // Return an error message or perform additional actions if needed
    echo '<script>alert("Failed to Delete Exam Time Table")
    window.location.href = "it1.php";</script>';
}
$conn->close();
?>
